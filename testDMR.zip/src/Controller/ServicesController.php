<?php

namespace App\Controller;

use Symfony\Component\HttpFoundation\Session\SessionInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;

class ServicesController extends AbstractController
{
    /**
    * @Route("/", name="index")
    */
    // Con esta función hago que haga render de la página principal
    public function index()
    {
        return $this->render('services/index.html.twig');
    }
    /**
    * @Route("/servicios", name="servicios")
    */
    // Con esta función hago que haga render de la página de servicios
    public function servicios()
    {
       return $this->render('services/servicios.html.twig');
    }
    /**
    * @Route("/proyectos/{page?1}", name="proyectos")
    */
    // Con esta función hago que haga render de la página de proyectos y cuando la variable page cambie a 2 haga render de ésta,
    // también hace que si la url cambia a cualquier otro numero o nombre me redirija a la primera página de proyectos
    public function proyectos($page)
    {
        if ($page ==  1){
            return $this->render('services/proyectos.html.twig');
        }
        else if ($page ==  2){
            return $this->render('services/proyectos_page2.html.twig');
        }
        else {
            return $this->redirectToRoute('proyectos', [
                'page' => 1
            ]);
        }
    }
    /**
    * @Route("/nosotros", name="nosotros")
    */
    // Con esta función hago que haga render de la página de nosotros
    public function nosotros()
    {
        return $this->render('services/nosotros.html.twig');
    }
    /**
    * @Route("/contacto", name="contacto")
    */
    // Con esta función hago que haga render de la página de contacto
    public function contacto()
    {
        return $this->render('services/contacto.html.twig');
    }
    /**
    * @Route("/contacto/preview", name="contacto2")
    */
    // Con esta función hago que haga render de la página de contacto2 y pida los datos de los inputs
    public function send(Request $request)
    {
        $nombre = $request->request->get('name');
        $email = $request->request->get('email');
        $website = $request->request->get('website');
        $asunto = $request->request->get('subject');
        $mensaje = $request->request->get('message');
        if ($website == 0){
            $website = "Campo vacío";
        }
        if ($asunto == 0){
            $asunto = "Campo vacío";
        }
        return $this->render('services/contacto2.html.twig', [
            'nombre' => $nombre,
            'email' => $email,
            'website' => $website,
            'asunto' => $asunto,
            'mensaje' => $mensaje,
        ]);
    }
    /**
    * @Route("/login", name="login")
    */
    public function login(SessionInterface $session)
    {
        $login = $session->get('username');
        if ($login != "") {
            $mensaje = "Usuario ".$login." conectado.";
        } else {
            $mensaje = "Introduce tus datos de usuario para iniciar la sesión.";
        }
        return $this->render('services/login.html.twig', [
            'mensajesesion' => $mensaje,
            'login' => $login
        ]);
    }
    /**
    * @Route("/loggedin", name="logging")
    */
    public function logging(Request $request, SessionInterface $session)
    {
        $login = $request->request->get('user'); 
        if ($login != "") {
            $session->set('username', $login);
            $mensaje = "Usuario ".$login." conectado.";
        } else {
            $mensaje = "Introduce tus datos de usuario para iniciar la sesión.";
        }
        return $this->render('services/login.html.twig', [
            'mensajesesion' => $mensaje,
            'login' => $login
        ]);
    }
    /**
    * @Route("/logout", name="logout")
    */
    public function logout(SessionInterface $session)
    {
        $session->invalidate();
        return $this->redirectToRoute('index');
    }
}
